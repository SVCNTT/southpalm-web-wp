<?php
/*
Plugin Name: Monolit Add-ons
Plugin URI: https://demowp.cththemes.net/monolit/
Description: A custom plugin for Monolit Responsive Architecture Wordpress Theme
Version: 1.1
Author: CTHthemes
Author URI: http://themeforest.net/user/cththemes
Text Domain: monolit-add-ons
Domain Path: /languages/
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/
if ( ! defined('ABSPATH') ) {
    die('Please do not load this file directly!');
}
define ('CTH_MONOLIT_DIR',plugin_dir_path(__FILE__ ));
define ('CTH_MONOLIT_DIR_URL',plugin_dir_url(__FILE__ ));
// admin style
add_action('admin_head', 'cth_monolit_admin_style');
if(!function_exists('cth_monolit_admin_style')){
    function cth_monolit_admin_style() {
        echo '<link rel="stylesheet" href="'.CTH_MONOLIT_DIR_URL.'assets/admin/style.css" type="text/css" media="all" />';
    } 
}

function cth_register_cpt_Portfolio() {
    
    $labels = array( 
        'name' => __( 'Portfolio', 'monolit-add-ons' ),
        'singular_name' => __( 'Portfolio', 'monolit-add-ons' ),
        'add_new' => __( 'Add New Portfolio', 'monolit-add-ons' ),
        'add_new_item' => __( 'Add New Portfolio', 'monolit-add-ons' ),
        'edit_item' => __( 'Edit Portfolio', 'monolit-add-ons' ),
        'new_item' => __( 'New Portfolio', 'monolit-add-ons' ),
        'view_item' => __( 'View Portfolio', 'monolit-add-ons' ),
        'search_items' => __( 'Search Portfolios', 'monolit-add-ons' ),
        'not_found' => __( 'No Portfolios found', 'monolit-add-ons' ),
        'not_found_in_trash' => __( 'No Portfolios found in Trash', 'monolit-add-ons' ),
        'parent_item_colon' => __( 'Parent Portfolio:', 'monolit-add-ons' ),
        'menu_name' => __( 'Monolit Portfolios', 'monolit-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Portfolios',
        'supports' => array( 'title', 'editor', 'thumbnail','comments'/*, 'post-formats'*/),
        'taxonomies' => array('portfolio_cat'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => plugin_dir_url( __FILE__ ) .'assets/admin_ico_portfolio.png', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('portfolio','monolit-add-ons') , 'with_front' => false ),
        'capability_type' => 'post'
    );

    register_post_type( 'portfolio', $args );
}

//Register Portfolio 
add_action( 'init', 'cth_register_cpt_Portfolio' );


//create a custom taxonomy name it Skills for your posts

function cth_create_Skills_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like categories
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Portfolio Categories', 'monolit-add-ons' ),
    'singular_name' => __( 'Category', 'monolit-add-ons' ),
    'search_items' =>  __( 'Search Categories','monolit-add-ons' ),
    'all_items' => __( 'All Categories','monolit-add-ons' ),
    'parent_item' => __( 'Parent Category','monolit-add-ons' ),
    'parent_item_colon' => __( 'Parent Category:','monolit-add-ons' ),
    'edit_item' => __( 'Edit Category','monolit-add-ons' ), 
    'update_item' => __( 'Update Category','monolit-add-ons' ),
    'add_new_item' => __( 'Add New Category','monolit-add-ons' ),
    'new_item_name' => __( 'New Category Name','monolit-add-ons' ),
    'menu_name' => __( 'Portfolio Categories','monolit-add-ons' ),
  );     

// Now register the taxonomy

  register_taxonomy('portfolio_cat',array('portfolio'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_in_nav_menus'=> true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => __('portfolio_cat','monolit-add-ons') , 'with_front' => false ),
  ));

}

//Add Portfolio Skills
    
add_action( 'init', 'cth_create_Skills_hierarchical_taxonomy', 0 );


if(!function_exists('cth_portfolio_columns_head')){
    function cth_portfolio_columns_head($defaults) {
        $defaults['cth_portfolio_thumbnail'] = 'Thumbnail';
        $defaults['cth_portfolio_id'] = 'ID';
        
        //unset($defaults['date']);
        return $defaults;
    }
}
if(!function_exists('cth_portfolio_columns_content')){
    // CUSTOM POSTS
    function cth_portfolio_columns_content($column_name, $post_ID) {
        if ($column_name == 'cth_portfolio_id') {
            echo $post_ID;
        }
        if ($column_name == 'cth_portfolio_thumbnail') {
            echo get_the_post_thumbnail( $post_ID, 'full', array('style'=>'width:100px;height:auto;') );
        }
    }
}

add_filter('manage_portfolio_posts_columns', 'cth_portfolio_columns_head', 10);
add_action('manage_portfolio_posts_custom_column', 'cth_portfolio_columns_content', 10, 2);

if(!function_exists('cth_portfolio_cat_columns_head')){
    function cth_portfolio_cat_columns_head($defaults) {
        $defaults['portfolio_cat_id'] = __('ID','monolit-add-ons');
        return $defaults;
    }
}

if(!function_exists('cth_portfolio_cat_columns_content')){
    function cth_portfolio_cat_columns_content($c, $column_name, $term_id) {
        if ($column_name == 'portfolio_cat_id') {
            echo $term_id;
        }
    }
}
add_filter('manage_edit-portfolio_cat_columns', 'cth_portfolio_cat_columns_head');
add_filter('manage_portfolio_cat_custom_column', 'cth_portfolio_cat_columns_content', 10, 3);


function cth_register_cpt_Cth_Testimonial() {
    
    $labels = array( 
        'name' => __( 'Testimonial', 'monolit-add-ons' ),
        'singular_name' => __( 'Testimonial', 'monolit-add-ons' ),
        'add_new' => __( 'Add New Testimonial', 'monolit-add-ons' ),
        'add_new_item' => __( 'Add New Testimonial', 'monolit-add-ons' ),
        'edit_item' => __( 'Edit Testimonial', 'monolit-add-ons' ),
        'new_item' => __( 'New Testimonial', 'monolit-add-ons' ),
        'view_item' => __( 'View Testimonial', 'monolit-add-ons' ),
        'search_items' => __( 'Search Testimonials', 'monolit-add-ons' ),
        'not_found' => __( 'No Testimonials found', 'monolit-add-ons' ),
        'not_found_in_trash' => __( 'No Testimonials found in Trash', 'monolit-add-ons' ),
        'parent_item_colon' => __( 'Parent Testimonial:', 'monolit-add-ons' ),
        'menu_name' => __( 'Monolit Testimonials', 'monolit-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Testimonials',
        'supports' => array( 'title', 'editor', 'thumbnail'/*,'comments', 'post-formats'*/),
        //'taxonomies' => array('post_tag'),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-format-chat', 
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('cth_testimonial','monolit-add-ons') , 'with_front' => false ),
        'capability_type' => 'post'
    );

    register_post_type( 'cth_testimonial', $args );
}
// Register Service 
add_action( 'init', 'cth_register_cpt_Cth_Testimonial' );
if(!function_exists('cth_testimonial_columns_head')){
    function cth_testimonial_columns_head($defaults) {
        $defaults['cth_testimonial_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('cth_testimonial_columns_content')){
    // CUSTOM POSTS
    function cth_testimonial_columns_content($column_name, $post_ID) {
        if ($column_name == 'cth_testimonial_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_cth_testimonial_posts_columns', 'cth_testimonial_columns_head', 10);
add_action('manage_cth_testimonial_posts_custom_column', 'cth_testimonial_columns_content', 10, 2);

function Monolit_Add_ons_register_cpt_Monolit_Timeline() {
    
    $labels = array( 
        'name' => __( 'Timeline', 'monolit-add-ons' ),
        'singular_name' => __( 'Timeline', 'monolit-add-ons' ),
        'add_new' => __( 'Add New Timeline', 'monolit-add-ons' ),
        'add_new_item' => __( 'Add New Timeline', 'monolit-add-ons' ),
        'edit_item' => __( 'Edit Timeline', 'monolit-add-ons' ),
        'new_item' => __( 'New Timeline', 'monolit-add-ons' ),
        'view_item' => __( 'View Timeline', 'monolit-add-ons' ),
        'search_items' => __( 'Search Timelines', 'monolit-add-ons' ),
        'not_found' => __( 'No Timelines found', 'monolit-add-ons' ),
        'not_found_in_trash' => __( 'No Timelines found in Trash', 'monolit-add-ons' ),
        'parent_item_colon' => __( 'Parent Timeline:', 'monolit-add-ons' ),
        'menu_name' => __( 'Monolit Timelines', 'monolit-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Timelines',
        'supports' => array( 'title', 'editor', 'thumbnail'/*,'comments', 'post-formats'*/),
        //'taxonomies' => array('post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' => 'dashicons-feedback', 
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('monolit_timeline','monolit-add-ons') , 'with_front' => false ),
        'capability_type' => 'post'
    );

    register_post_type( 'monolit_timeline', $args );
}
// Register Service 
add_action( 'init', 'Monolit_Add_ons_register_cpt_Monolit_Timeline' );
if(!function_exists('monolit_timeline_columns_head')){
    function monolit_timeline_columns_head($defaults) {
        $defaults['monolit_timeline_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('monolit_timeline_columns_content')){
    // CUSTOM POSTS
    function monolit_timeline_columns_content($column_name, $post_ID) {
        if ($column_name == 'monolit_timeline_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_monolit_timeline_posts_columns', 'monolit_timeline_columns_head', 10);
add_action('manage_monolit_timeline_posts_custom_column', 'monolit_timeline_columns_content', 10, 2);

function Monolit_Add_ons_register_cpt_Monolit_Service() {
    
    $labels = array( 
        'name' => __( 'Service', 'monolit-add-ons' ),
        'singular_name' => __( 'Service', 'monolit-add-ons' ),
        'add_new' => __( 'Add New Service', 'monolit-add-ons' ),
        'add_new_item' => __( 'Add New Service', 'monolit-add-ons' ),
        'edit_item' => __( 'Edit Service', 'monolit-add-ons' ),
        'new_item' => __( 'New Service', 'monolit-add-ons' ),
        'view_item' => __( 'View Service', 'monolit-add-ons' ),
        'search_items' => __( 'Search Services', 'monolit-add-ons' ),
        'not_found' => __( 'No Services found', 'monolit-add-ons' ),
        'not_found_in_trash' => __( 'No Services found in Trash', 'monolit-add-ons' ),
        'parent_item_colon' => __( 'Parent Service:', 'monolit-add-ons' ),
        'menu_name' => __( 'Monolit Services', 'monolit-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Services',
        'supports' => array( 'title', 'editor', 'thumbnail'/*,'comments', 'post-formats'*/),
        //'taxonomies' => array('post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' =>  plugin_dir_url( __FILE__ ) .'assets/admin_icon_services.png',//'dashicons-feedback', 
        'show_in_nav_menus' => false,
        'publicly_queryable' => true,
        'exclude_from_search' => true,
        'has_archive' => false,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('monolit_service','monolit-add-ons') , 'with_front' => false ),
        'capability_type' => 'post'
    );

    register_post_type( 'monolit_service', $args );
}
// Register Service 
add_action( 'init', 'Monolit_Add_ons_register_cpt_Monolit_Service' );
if(!function_exists('monolit_service_columns_head')){
    function monolit_service_columns_head($defaults) {
        $defaults['monolit_service_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('monolit_service_columns_content')){
    // CUSTOM POSTS
    function monolit_service_columns_content($column_name, $post_ID) {
        if ($column_name == 'monolit_service_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_monolit_service_posts_columns', 'monolit_service_columns_head', 10);
add_action('manage_monolit_service_posts_custom_column', 'monolit_service_columns_content', 10, 2);

//register Team Member post type
function Monolit_Add_ons_register_cpt_Monolit_Member() {
    
    $labels = array( 
        'name' => __( 'Members', 'monolit-add-ons' ),
        'singular_name' => __( 'Member', 'monolit-add-ons' ),
        'add_new' => __( 'Add New Member', 'monolit-add-ons' ),
        'add_new_item' => __( 'Add New Member', 'monolit-add-ons' ),
        'edit_item' => __( 'Edit Member', 'monolit-add-ons' ),
        'new_item' => __( 'New Member', 'monolit-add-ons' ),
        'view_item' => __( 'View Member', 'monolit-add-ons' ),
        'search_items' => __( 'Search Members', 'monolit-add-ons' ),
        'not_found' => __( 'No Members found', 'monolit-add-ons' ),
        'not_found_in_trash' => __( 'No Members found in Trash', 'monolit-add-ons' ),
        'parent_item_colon' => __( 'Parent Member:', 'monolit-add-ons' ),
        'menu_name' => __( 'Monolit Members', 'monolit-add-ons' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Members',
        'supports' => array( 'title', 'editor', 'thumbnail'/*,'comments', 'post-formats'*/),
        //'taxonomies' => array('post_tag'),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,
        'menu_icon' =>  'dashicons-groups',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array( 'slug' => __('monolit_member','monolit-add-ons') , 'with_front' => false ),
        'capability_type' => 'post'
    );

    register_post_type( 'monolit_member', $args );
}
// Register Member 
add_action( 'init', 'Monolit_Add_ons_register_cpt_Monolit_Member' );
if(!function_exists('monolit_member_columns_head')){
    function monolit_member_columns_head($defaults) {
        $defaults['monolit_member_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('monolit_member_columns_content')){
    // CUSTOM POSTS
    function monolit_member_columns_content($column_name, $post_ID) {
        if ($column_name == 'monolit_member_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_monolit_member_posts_columns', 'monolit_member_columns_head', 10);
add_action('manage_monolit_member_posts_custom_column', 'monolit_member_columns_content', 10, 2);

// Page ID
if(!function_exists('monolit_page_columns_head')){
    function monolit_page_columns_head($defaults) {
        $defaults['page_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('monolit_page_columns_content')){
    // CUSTOM POSTS
    function monolit_page_columns_content($column_name, $post_ID) {
        if ($column_name == 'page_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_page_posts_columns', 'monolit_page_columns_head', 10);
add_action('manage_page_posts_custom_column', 'monolit_page_columns_content', 10, 2);

// Post ID
if(!function_exists('monolit_post_columns_head')){
    function monolit_post_columns_head($defaults) {
        $defaults['post_id'] = 'ID';
        return $defaults;
    }
}
if(!function_exists('monolit_post_columns_content')){
    // CUSTOM POSTS
    function monolit_post_columns_content($column_name, $post_ID) {
        if ($column_name == 'post_id') {
            echo $post_ID;
        }
    }
}

add_filter('manage_post_posts_columns', 'monolit_post_columns_head', 10);
add_action('manage_post_posts_custom_column', 'monolit_post_columns_content', 10, 2);


add_action( 'init', 'add_excerpts_to_monolit_post_types' );
function add_excerpts_to_monolit_post_types() {
    add_post_type_support( 'monolit_member', 'excerpt' );
    add_post_type_support( 'portfolio', 'excerpt' );
}

//add new image size for recent posts widget

function monolit_add_ons_add_new_image_size() {
    add_image_size( 'recent_thumb', 107, 69, true ); //mobile
}

add_action( 'init', 'monolit_add_ons_add_new_image_size' );

/**
 * Portfolio archive rewrite rules
 * example.com/portfolio/2015/01/30
 * @since Monolit 1.0
*/

/**
 * Custom post type specific rewrite rules
 * @return wp_rewrite Rewrite rules handled by WordPress
 */
function monolit_portfolio_rewrite_rules($wp_rewrite)
{
    // Here we're hardcoding the CPT in, portfolio in this case
    $rules = monolit_portfolio_generate_date_archives('portfolio', $wp_rewrite);
    $wp_rewrite->rules = $rules + $wp_rewrite->rules;
    return $wp_rewrite;
}
add_action('generate_rewrite_rules', 'monolit_portfolio_rewrite_rules');

/**
 * Generate date archive rewrite rules for a given custom post type
 * @param  string $cpt slug of the custom post type
 * @return rules       returns a set of rewrite rules for WordPress to handle
 */
function monolit_portfolio_generate_date_archives($cpt, $wp_rewrite)
{
    $rules = array();

    $post_type = get_post_type_object($cpt);
    if(!isset($post_type)){
        return $rules;
    }
    $slug_archive = $post_type->has_archive;
    if ($slug_archive === false) {
        return $rules;
    }
    if ($slug_archive === true) {
        // Here's my edit to the original function, let's pick up
        // custom slug from the post type object if user has
        // specified one.
        $slug_archive = $post_type->rewrite['slug'];
    }

    $dates = array(
        array(
            'rule' => "([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})",
            'vars' => array('year', 'monthnum', 'day')
        ),
        array(
            'rule' => "([0-9]{4})/([0-9]{1,2})",
            'vars' => array('year', 'monthnum')
        ),
        array(
            'rule' => "([0-9]{4})",
            'vars' => array('year')
        )
    );

    foreach ($dates as $data) {
        $query = 'index.php?post_type='.$cpt;
        $rule = $slug_archive.'/'.$data['rule'];

        $i = 1;
        foreach ($data['vars'] as $var) {
            $query.= '&'.$var.'='.$wp_rewrite->preg_index($i);
            $i++;
        }

        $rules[$rule."/?$"] = $query;
        $rules[$rule."/feed/(feed|rdf|rss|rss2|atom)/?$"] = $query."&feed=".$wp_rewrite->preg_index($i);
        $rules[$rule."/(feed|rdf|rss|rss2|atom)/?$"] = $query."&feed=".$wp_rewrite->preg_index($i);
        $rules[$rule."/page/([0-9]{1,})/?$"] = $query."&paged=".$wp_rewrite->preg_index($i);
    }
    return $rules;
}

//widgets
require_once CTH_MONOLIT_DIR .'/widgets/monolit_recent_posts.php';

function monolit_add_ons_register_widgets() {
    register_widget( 'Monolit_Recent_Posts' );
}

add_action( 'widgets_init', 'monolit_add_ons_register_widgets' );


function cth_monolit_plugins_init() {
    $plugin_dir = basename(dirname(__FILE__));
    // $plugin_dir = dirname(__FILE__);
    load_plugin_textdomain( 'monolit-add-ons', false, $plugin_dir . '/languages' );
}
add_action('plugins_loaded', 'cth_monolit_plugins_init');

/* Enable shortcode in widget text content */
add_filter('widget_text', 'do_shortcode');

// add_shortcode('gallery', '__return_false');

if(!function_exists('faicon_sc')) {

    function faicon_sc( $atts, $content="" ) {
    
        extract(shortcode_atts(array(
               'name' =>"magic",
               'class'=>'',
         ), $atts));

        $name = str_replace(array("fa fa-","fa-"), "", $name);
        //$name = str_replace(, "", $name);

        $classes = 'fa fa-'.$name;
        if(!empty($class)){
            $classes .= ' '.$class;
        }
        
        return '<i class="'.$classes.'"></i>'. $content;
     
    }
        
    add_shortcode( 'faicon', 'faicon_sc' ); //Icon
}
if(!function_exists('monolit_separator_sc')) {

    function monolit_separator_sc( $atts, $content="" ) {
    
        
        
        return '<div class="separator"></div><div class="clearfix"></div>';
     
    }
        
    add_shortcode( 'monolit_separator', 'monolit_separator_sc' ); //Icon
}